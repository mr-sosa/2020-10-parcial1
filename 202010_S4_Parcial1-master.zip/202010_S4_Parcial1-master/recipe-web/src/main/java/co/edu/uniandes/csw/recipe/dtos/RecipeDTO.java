/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.uniandes.csw.recipe.dtos;

import co.edu.uniandes.csw.recipe.entities.RecipeEntity;
import java.io.Serializable;

/**
 *
 * @author estudiante
 */
public class RecipeDTO implements  Serializable{
    
    private Long id ; 
    
    private String name;
   
    private Integer anio;
    
    private String tipo;
    
    private String descripcion;

    public RecipeDTO() {
    }
    
    public RecipeDTO(RecipeEntity recipeEntity)
    {
        if( recipeEntity != null)
        {
            this.id = recipeEntity.getId();
            this.name = recipeEntity.getName();
            this.anio = recipeEntity.getAnio();
            this.descripcion = recipeEntity.getDescripcion();
            this.tipo = recipeEntity.getTipo();
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getAnio() {
        return anio;
    }

    public void setAnio(Integer anio) {
        this.anio = anio;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
     public RecipeEntity toEntity() {
        RecipeEntity recipeEntity = new RecipeEntity();
        recipeEntity.setAnio(this.anio);
        recipeEntity.setDescripcion(this.descripcion);
        recipeEntity.setName(this.name);
        recipeEntity.setTipo(this.tipo);
        recipeEntity.setId(this.id);
        return recipeEntity;
    }

   
    
}
